#import pyautogui
#pyautogui.displayMousePosition()
from pyautogui import *
import pyautogui
import time
import keyboard
import random
import sys
import win32api, win32con

#[0] = R
#[1] = G
#[2] = B 

# Lock In Position: X: 964 Y:  730 Regular RGB: (255, 255, 255)

# Astra Position: X: 626 Y:  843 Regular RGB: (137, 104,  93)
# Breach Position: X: 716 Y:  844 Regular RGB: (170, 124, 104)
# Brimstone Position: X: 800 Y:  840 Regular RGB: (210, 163, 128)
# Chamber Position: X: 874 Y:  842 Regular RGB: (173, 126, 110)
# Cypher Position: X: 954 Y:  840 Regular RGB: ( 20,  21,  31)
# Deadlock Position: X: 1040 Y:  844 Regular RGB: (214, 164, 148)
# Fade Position: X: 1135 Y:  844 Regular RGB: (220, 178, 159)
# Gekko Position: X: 1216 Y:  846 Regular RGB: (173, 128, 104)
# Harbor Position: X: 1302 Y:  840 Regular RGB: (140,  92,  74)

# Iso Position: X: 631 Y:  930 Regular RGB: (198, 157, 132)
# Jett Position: X: 717 Y:  932 Regular RGB: (222, 192, 178)
# KAY/O Position: X: 802 Y:  924 Regular RGB: ( 64, 118, 250)
# Killjoy Position: X: 878 Y:  923 Regular RGB: (198, 212, 231)
# Neon Position: X: 959 Y:  923 Regular RGB: ( 34,  36,  59)
# Omen Position: X: 1051 Y:  927 Regular RGB: ( 24,  20, 132)
# Phoenix Position: X: 1143 Y:  927 Regular RGB: (130,  91,  85)
# Raze Position: X: 1217 Y:  927 Regular RGB: (146,  93,  78)
# Reyna Position: X: 1305 Y:  910 Regular RGB: (198, 150, 140)

# Sage Position: X: 632 Y:  1014 Regular RGB: (240, 196, 170)
# Skye Position: X: 713 Y:  1014 Regular RGB: (182, 173, 153)
# Sova Position: X: 792 Y:  1011 Regular RGB: (206, 163, 154)
# Viper Position: X: 883 Y:  1009 Regular RGB: ( 27,  31,  49)
# Yoru Position: X: 963 Y:  1012 Regular RGB: (165, 125, 140)

agent_positions = {
    "Astra": (626, 843, 137),
    "Breach": (716, 844, 170),
    "Brimstone": (800, 840, 210),
    "Chamber": (874, 842, 173),
    "Cypher": (954, 840, 20),
    "Deadlock": (1040, 844, 214),
    "Fade": (1135, 844, 220),
    "Gekko": (1216, 846, 173),
    "Harbor": (1302, 840, 140),
    "Iso": (631, 930, 198),
    "Jett": (717, 932, 222),
    "KAY/O": (802, 924, 64),
    "Killjoy": (878, 923, 198),
    "Neon": (959, 923, 34),
    "Omen": (1051, 927, 24),
    "Phoenix": (1143, 927, 130),
    "Raze": (1217, 927, 146),
    "Reyna": (1305, 910, 198),
    "Sage": (632, 1014, 240),
    "Skye": (713, 1014, 182),
    "Sova": (792, 1011, 206),
    "Viper": (883, 1009, 27),
    "Yoru": (963, 1012, 165),
}

selected_agent = sys.argv[1]

def click(x,y):
    win32api.SetCursorPos((x,y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,0,0)
    time.sleep(0.01) #This pauses the script for 0.01 seconds
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,0,0)
    
while not keyboard.is_pressed('p'):
    if selected_agent in agent_positions:
        x, y, rgb = agent_positions[selected_agent]
        if pyautogui.pixel(x, y)[0] == rgb:
            click(x, y)
            time.sleep(0.001)
            for _ in range(2):
                click(964, 730)
                time.sleep(0.001)