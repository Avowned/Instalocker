import os
import sys
import subprocess
from customtkinter import *
from PIL import Image

app = CTk()
app.title("Instalocker")
app.geometry("500x400")
icon_path = os.path.join(os.path.dirname(__file__), "Instalocker.ico")  # Replace with your icon path
app.iconbitmap(icon_path)

# Keep track of the checkbox states
checkbox_states = {}

# Keep track of the subprocess
current_process = None

# Keep track of the notification event ID
notification_event_id = None

def checkbox_handler(checkbox_name):
    global current_process, notification_event_id
    
    # Check if the checkbox is being checked or unchecked
    if checkbox_states.get(checkbox_name, True):
        # Terminate the current process if it exists
        if current_process and current_process.poll() is None:
            current_process.terminate()

        # Cancel the previous notification event
        if notification_event_id:
            app.after_cancel(notification_event_id)

        notification_label.configure(text=f"Instalocking {checkbox_name}!")

        # Pass the selected agent's name to bot.py as a command-line argument
        bot_script_path = os.path.join(os.path.dirname(__file__), "bot.py")
        current_process = subprocess.Popen(["python", bot_script_path, checkbox_name])

        # Schedule a new notification event
        notification_event_id = app.after(3000, clear_notification)

    # Update the checkbox state
    checkbox_states[checkbox_name] = not checkbox_states.get(checkbox_name, True)

def clear_notification():
    global notification_event_id
    notification_label.configure(text="")
    notification_event_id = None

def create_checkbox_with_image(name, image_path, checkbox_position, image_position):
    checkbox = CTkCheckBox(master=app, text=name, fg_color="#FF0000",
                           hover_color="#5426ca", checkbox_height=20,
                           checkbox_width=20, command=lambda n=name: checkbox_handler(n))
    checkbox.place(relx=checkbox_position[0], rely=checkbox_position[1], anchor="center")

    # Create CTkImage with light and dark mode images
    my_image = CTkImage(light_image=Image.open(image_path),
                        dark_image=Image.open(image_path),
                        size=(20, 20))

    # Create CTkLabel to display the image
    image_label = CTkLabel(app, image=my_image, text="")
    image_label.place(relx=image_position[0], rely=image_position[1], anchor="center")

def theme_handler(value):
    # change light/dark theme logic
    if value == "Light Theme":
        set_appearance_mode("light")
        themecombobox.configure(text_color="#FFFFFF", dropdown_text_color="#FFFFFF")
        notification_label.configure(fg_color="#ebebeb", text_color="#00bf32")
    if value == "Dark Theme":
        set_appearance_mode("dark")

# Create theme combobox
themecombobox = CTkComboBox(master=app, values=["Dark Theme", "Light Theme"], fg_color="#5E0000",
                            border_color="#FF0000", dropdown_fg_color="#4A0000",
                            dropdown_hover_color="#8c1c3c", command=theme_handler)
themecombobox.place(relx=0.7, rely=0.03)

# Create notification label
notification_label = CTkLabel(app, text="", font=("Arial", 15))
notification_label.configure(fg_color="#242424", text_color="#00bf32")
notification_label.place(relx=0.5, rely=0.9, anchor="center")

script_dir = os.path.dirname(__file__)
agent_icons_folder = "AgentIcons"

# Create checkboxes with images
create_checkbox_with_image("Astra", os.path.join(script_dir, agent_icons_folder, "Astra.png"), (0.14, 0.18), (0.18, 0.18))
create_checkbox_with_image("Breach", os.path.join(script_dir, agent_icons_folder, "Breach.png"), (0.38, 0.18), (0.44, 0.18))
create_checkbox_with_image("Brimstone", os.path.join(script_dir, agent_icons_folder, "Brimstone.png"), (0.62, 0.18), (0.715, 0.18))
create_checkbox_with_image("Chamber", os.path.join(script_dir, agent_icons_folder, "Chamber.png"), (0.86, 0.18), (0.94, 0.18))
create_checkbox_with_image("Cypher", os.path.join(script_dir, agent_icons_folder, "Cypher.png"), (0.14, 0.28), (0.20, 0.28))
create_checkbox_with_image("Deadlock", os.path.join(script_dir, agent_icons_folder, "Deadlock.png"), (0.38, 0.28), (0.47, 0.28))
create_checkbox_with_image("Fade", os.path.join(script_dir, agent_icons_folder, "Fade.png"), (0.62, 0.28), (0.66, 0.28))
create_checkbox_with_image("Gekko", os.path.join(script_dir, agent_icons_folder, "Gekko.png"), (0.86, 0.28), (0.915, 0.28))
create_checkbox_with_image("Harbor", os.path.join(script_dir, agent_icons_folder, "Harbor.png"), (0.14, 0.38), (0.19, 0.38))
create_checkbox_with_image("Iso", os.path.join(script_dir, agent_icons_folder, "Iso.png"), (0.38, 0.38), (0.395, 0.38))
create_checkbox_with_image("Jett", os.path.join(script_dir, agent_icons_folder, "Jett.png"), (0.62, 0.38), (0.65, 0.38))
create_checkbox_with_image("KAY/O", os.path.join(script_dir, agent_icons_folder, "KAYO.png"), (0.86, 0.38), (0.915, 0.38))
create_checkbox_with_image("Killjoy", os.path.join(script_dir, agent_icons_folder, "Killjoy.png"), (0.14, 0.48), (0.19, 0.48))
create_checkbox_with_image("Neon", os.path.join(script_dir, agent_icons_folder, "Neon.png"), (0.38, 0.48), (0.42, 0.48))
create_checkbox_with_image("Omen", os.path.join(script_dir, agent_icons_folder, "Omen.png"), (0.62, 0.48), (0.67, 0.48))
create_checkbox_with_image("Phoenix", os.path.join(script_dir, agent_icons_folder, "Phoenix.png"), (0.86, 0.48), (0.93, 0.48))
create_checkbox_with_image("Raze", os.path.join(script_dir, agent_icons_folder, "Raze.png"), (0.14, 0.58), (0.18, 0.58))
create_checkbox_with_image("Reyna", os.path.join(script_dir, agent_icons_folder, "Reyna.png"), (0.38, 0.58), (0.43, 0.58))
create_checkbox_with_image("Sage", os.path.join(script_dir, agent_icons_folder, "Sage.png"), (0.62, 0.58), (0.66, 0.58))
create_checkbox_with_image("Skye", os.path.join(script_dir, agent_icons_folder, "Skye.png"), (0.86, 0.58), (0.90, 0.58))
create_checkbox_with_image("Sova", os.path.join(script_dir, agent_icons_folder, "Sova.png"), (0.14, 0.68), (0.18, 0.68))
create_checkbox_with_image("Viper", os.path.join(script_dir, agent_icons_folder, "Viper.png"), (0.38, 0.68), (0.42, 0.68))
create_checkbox_with_image("Yoru", os.path.join(script_dir, agent_icons_folder, "Yoru.png"), (0.62, 0.68), (0.655, 0.68))

app.mainloop()